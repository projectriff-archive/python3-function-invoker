def upper(val):
    return val.upper()