from helpers import upper
def handler(val):
    return upper(val)